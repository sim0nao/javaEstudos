/*
Objetivo: exemplificar Switch Case
4-4-9
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Exe_sweetcase {
    public static void main (String args[]){
        int opc;
        opc=Integer.parseInt(JOptionPane.showInputDialog("Digite a opção: /n 1- Tabuada do 3: /n 2-Tabuada do 6: /n Tabuada do 9:" ));
        
        switch (opc)
                {
            case 1: 
                    for (int n1=3, c=1; c<=10; c++){     
                        int n2= n1*c;
                        JOptionPane.showMessageDialog(null, n2);
                    }
                    
            case 2:
                    for (int n1=6, c=1; c<=10; c++){
                        int n3= n1*c;
                        JOptionPane.showMessageDialog(null, n3);
                    }
                    
            case 3:
                    for (int n1=9, c=1; c<=10; c++){
                        int n4= n1*c;
                        JOptionPane.showMessageDialog(null,n4);
                    }
        break;            
        }
    }
}
