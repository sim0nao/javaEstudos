/*
 Objetivo:Receba um valor inteiro. Verifique e mostre se é divisível por 2 e 3.
Data de criação: 05-03-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio24
{
    public static void main (String args[])
    {
     int n1;
     n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
     if((n1%2==0)&&(n1%3==0))
     {
         JOptionPane.showMessageDialog(null, "O número é divisivel por 2 e 3");
     }
     
        else
     {
         JOptionPane.showMessageDialog(null, "O número ão é divisivel or 2 e por 3");
     }   
    }
    
}
