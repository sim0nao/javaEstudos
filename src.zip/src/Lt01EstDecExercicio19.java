/*
Objetivo: Receba 2 valores reais. Calcule e mostre o maior deles.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio19 {
   public static void main (String args[]){
       double n1,n2,n3;
       n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
       n2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número"));
       if (n1>n2)
       {
           n3= n1-n2;
           JOptionPane.showMessageDialog(null,"A diferença é de" +n3);
       }
       else
       {
           n3=n2-n1;
           JOptionPane.showMessageDialog(null,"A diferença é de" +n3);
       }
    
} 
    
}
