/*
 Objetivo:Receba 2 ângulos de um triângulo. Calcule e mostre o valor do 3º ângulo.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio14 {
    public static void main (String args[])
    {
     int a1,a2,a3;
     a1=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor do 1º ângulo:"));
     a2=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor do 2º ângulo:"));
     a3=180-(a1+a2);
     JOptionPane.showMessageDialog(null,"O 3º ângulo do triângulo é de:" +a3);
     
    }
    
}
