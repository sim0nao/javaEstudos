/*
Objetivo:Receba os coeficientes A, B, C de uma equação do 2º grau (AX²+BX+C=0). Calcule
e mostre as raízes reais. (Considerar que a equação tem 2 raízes).
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio5
{
    public static void main (String args[])            
    {
double a,b,c,delta,x1,x2;
a=Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de a"));
b=Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de b"));
c=Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de c"));
delta=(b*b)-(4*a*c);
x1=(-b+(delta*delta)/(2*a));
x2=(-b-(delta*delta)/(2*a));
JOptionPane.showMessageDialog(null,"As raízes da equação são:" +x1 +x2);
    }

}
