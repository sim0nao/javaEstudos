/*
18.Receba 2 valores inteiros.Calcule e mostre o resultado da diferença do maior
pelo menor.
Data de criação: 10-04-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_Proced_Exe18 {
    public static void main (String args[]){
        int n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
        int n2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número:"));
        Dif(n1,n2);
    
}
static void Dif (int x, int y){
    if(x>y){
        int z=x-y;
        JOptionPane.showMessageDialog(null,"A diferença é:" +z);    
    }
    
    else{
        int z=y-x;
        JOptionPane.showMessageDialog(null,"A diferença é:" +z);
        
    } 
}
    
}
