/*
 Objetivo:Receba o raio de uma circunferência. Calcule e mostre o comprimento da
circunferência.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio11 {
    public static void main (String args[])
    {
        double R;
        R=Integer.parseInt(JOptionPane.showInputDialog("Digite o raio da circunferência:"));
        R=3.14*(R*R);
        javax.swing.JOptionPane.showMessageDialog(null,"A área da circunferência é de:" +R);
        
    }
    
}
