/*
 16. Receba a quantidade de horas trabalhadas, o valor por hora, o percentual de
desconto e o número de descendentes. Calcule o salário que será: as horas trabalhadas 
x o valor por hora. Calcule o salário líquido (= Salário Bruto – desconto). 
A cada dependente será acrescido R$ 100 no Salário Líquido. Exiba o salário a receber.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstDecExercicio16 {
    public static void main (String args[])
    {
     double q, vh,desc, dep, salb,sall;
     q=Integer.parseInt(JOptionPane.showInputDialog("Digite as horas trabalhadas:"));
     vh=Integer.parseInt(JOptionPane.showInputDialog("Digiteo valor das horas:"));
     desc=Integer.parseInt(JOptionPane.showInputDialog("Digite o percentual do desconto"));
     dep=Integer.parseInt(JOptionPane.showInputDialog("Digite o número de dependentes"));
     salb=(vh*q);
     desc= desc/100;
     sall=(salb-desc);
        if(dep>=1)
        {
        dep=dep*100;
        sall=sall+dep;
        JOptionPane.showMessageDialog(null,"O valor do salário será:" +sall);
        }
        else
        {
        JOptionPane.showMessageDialog(null,"O valor do salário será:" +sall);
        }
       
    }
    
}
