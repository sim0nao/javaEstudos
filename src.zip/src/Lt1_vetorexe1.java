/*
Objetivo:
Criar e coletar um vetor [50] inteiro. Calcular e exibir:
a.	A média dos valores entre 10 e 200;
b.	A soma dos números ímpares.
Data: 4-4-19
programadora: Simone Henrique
 */


import javax.swing.JOptionPane;
public class Lt1_vetorexe1 {
    public static void main (String args[]){
        int vet[]= new int [50];
        int soma=0, impar=0;
         for ( int cont=0; cont<50; cont++){
             vet[cont]=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
         
             if((vet[cont]>=10) && (vet[cont]<=200)){
                 soma=soma+vet[cont];
             }
              if (vet[cont]%2==1){
                 impar= impar+1;
              }   
        }
    
         JOptionPane.showMessageDialog(null,"A soma dos números é:" +soma); 
         JOptionPane.showMessageDialog(null,"Total de números impares:"+impar);
         }
}
    

    


