/*
Objetivo:Calcule a quantidade de litros gastos em uma viagem, sabendo que o automóvel faz 12 km/l. 
Receber o tempo de percurso e a velocidade média.
Data de criação: 31-03-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01FunExercicio31 {
    static int Quadrado (int cont){
        
        for (cont=10; cont<15; cont++ ){
            int quad=cont*cont;
            
        }
    }         
        
     
    public static void main (String args[]){
        int ret;
        for( int n1=10;n1<15; n1++){
        ret=Quadrado(n1);
        JOptionPane.showMessageDialog(null, ret);
        
        }
       
    
        
        
    
}
    
}
