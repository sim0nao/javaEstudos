/*
Objetivo:Receba um número inteiro. Calcule e mostre o seu fatorial.
Data de criação:01-04-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01FunExercicio32 {
    static int Fat (int f){
      
       for ( int c=1, n; f>=1; c--){
         f=f*c; 
        }
        return f; 
    }    
 public static void main (String args[]){
     int n, rec;
     n=Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
     rec= Fat(n);
     JOptionPane.showMessageDialog(null,rec);
     
 }   
 }