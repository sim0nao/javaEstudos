/*
Objetivo: Receba 4 notas bimestrais de um aluno. Calcule e mostre a média aritmética.
Mostre a mensagem de acordo com a média:
a. Se a média for >= 6,0 exibir “APROVADO”;
b. Se a média for >= 3,0 ou < 6,0 exibir “EXAME”;
c. Se a média for < 3,0 exibir “RETIDO”.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio21 {
    public static void main (String args[])
    {
     double n1,n2,n3,n4,Med;
     n1=Integer.parseInt(JOptionPane.showInputDialog("Digite a primeira nota"));
     n2=Integer.parseInt(JOptionPane.showInputDialog("Digite a segunda nota"));
     n3=Integer.parseInt(JOptionPane.showInputDialog("Digite a terceira nota"));
     n4=Integer.parseInt(JOptionPane.showInputDialog("Digite a quarta nota"));
     Med=(n1+n2+n3+n4)/4;
     if (Med>=6)
     {
         JOptionPane.showMessageDialog(null,"Aprovado!");
     }
     else if((Med>=3)&(Med<6))
                {
            JOptionPane.showMessageDialog(null,"Exame!");
            
                }
     else 
                {
                 JOptionPane.showMessageDialog(null,"Reprovado!");
                }
    }
    
}
