/*
Objetivo:Receba a temperatura em graus Celsius. Calcule e mostre sua temperatura convertida
em Fahenheit F= (9*C + 160) /5.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio4 
{
    public static void main (String args[])            
    {
double C,F;
C=Integer.parseInt(JOptionPane.showInputDialog("Digite a temperatura em Celsius:"));
F=((9*C+160)/5);
JOptionPane.showMessageDialog(null,"A temperatura em Fahenheit é de:" +F);
    }

    
}
