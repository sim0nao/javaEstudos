/*
Objetivo: Receba um número. Calcule e mostre a série 1 + 1/2 + 1/3 + ... + 1/N..
Data de criação:01-04-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01FunExercicio33 {
    
}
