/*
 Objetivo:Receba a quantidade de alimento em quilos. Calcule e mostre quantos dias
durará esse alimento sabendo que a pessoa consome 50g ao dia.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */
import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio13 {
    public static void main (String args[]) 
    {
    double kg;
    int D;
    kg=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de alimento em Kg:"));
    D= (int) (kg/0.5);
    JOptionPane.showMessageDialog(null,"O alimento irá durar" +D +"dias");
    
    
    }
    
    
}
