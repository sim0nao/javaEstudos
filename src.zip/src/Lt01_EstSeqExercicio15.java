/*
  Objetivo:Receba os valores de 2 catetos de um triângulo retângulo. Calcule e mostre a
hipotenusa.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio15 {
    public static void main (String args[])
   {
    
   double C1, C2, H;
   C1=Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de a"));
   C2=Double.parseDouble(JOptionPane.showInputDialog("Digite a temperatura em Celsius:"));
   H= (C1*C1)+(C2*C2);
   JOptionPane.showMessageDialog(null,"A hipotenusa será:" +H);
   
    
    } 
    
}
