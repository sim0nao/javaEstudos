/*
 20.Receba 3 coeficientes A, B, e C de uma equação do 2º grau da fórmula AX²+BX+C=0. 
Verifique e mostre a existência de raízes reais e se caso exista, calcule e mostre.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio20 {
    public static void main (String args[]) {
        int a,b,c,delta,x1,x2;
        a=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor de A"));
        b=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor de B"));
        c=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor de C"));
        delta=(b*b)-(4*a*c);
            if (delta<=0)
        {
            JOptionPane.showMessageDialog(null,"O valor de delta não é uma raíz real");
        }
            else
        {
            x1=(-b+(delta*delta)/(2*a));
            x2=(-b-(delta*delta)/(2*a));
            JOptionPane.showMessageDialog(null,"As raízes da equação são:" +x1 +x2);
        }
        
        
        
        
    
}
    
}
