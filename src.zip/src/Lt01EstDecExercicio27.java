/*
Objetivo: Receba o número de voltas, a extensão do circuito (em metros) e o tempo de
duração (minutos). Calcule e mostre a velocidade média em km/h.
Data de criação: 16-03-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio27 {
    public static void main (String args[]){
        double v1,v2,vm,t;
        v1=Integer.parseInt(JOptionPane.showInputDialog("Digite o número de voltas:"));
        v2=Integer.parseInt(JOptionPane.showInputDialog("Digite a extensão em metros:"));
        t=Integer.parseInt(JOptionPane.showInputDialog("Digite a duração do circuito em minutos:"));
        vm=v2/t*v1;
        if (v1>0)
        {
         JOptionPane.showMessageDialog(null,"A velocidade media foi de" +vm);
        }
        else
        {
         JOptionPane.showMessageDialog(null,"Você não completou nenhuma volta no circuito");
        }
        
        
        
        
        
    }
    
}
