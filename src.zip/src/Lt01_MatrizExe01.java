/*
Objetivo:Criar e carregar uma matriz [4][3] inteiro com quantidade de produtos vendidos em 4 semanas.
Calcular e exibir:
a.	A quantidade de cada produto vendido no mês;
b.	A quantidade de produtos vendidos por semana;
c.	O total de produtos vendidos no mês.

Data de criação: 10-04-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_MatrizExe01 {
    public static void main (String args[]){
        int Mat[ ][ ] = new int [4][3];
        int x=0; int y=0;
        carregaMat();
        Proced(Mat);
        
    }       
static void carregaMat(){
      int Mat[ ][ ] = new int [4][3];

       int x,y;
       for(x=0; x<4; x++){
           for(y=0; y<3; y++){
               Mat[x][y]=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade do produtos:"));
               
           }
       }
/*mostra matriz*/
    for(x=0; x<4; x++){
        for(y=0; y<3; y++){
            JOptionPane.showMessageDialog(null, Mat[x][y]);
        }
        
    }
}
        
  static void Proced ()
  int Mat[ ][ ] = new int [4][3];


      for(int x=0; x<4; x++){
          for(int y=0; y<1; y++){
              int soma= soma+Mat[x][y];
          }
          
      }
      
  }  
        

        
    
    
}
