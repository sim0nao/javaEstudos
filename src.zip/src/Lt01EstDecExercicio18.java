/*
 18.Receba 2 valores inteiros.Calcule e mostre o resultado da diferença do maior
pelo menor.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio18 {
    public static void main (String args[])
    {
     int N1,N2,N3;
     N1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
     N2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro valor:"));
     if (N1>N2)
     {
         N3=N1-N2;
         JOptionPane.showMessageDialog(null,"A difernça entre os valores é" +N3);
     }
     else
     {
         N3=N2-N1;
         JOptionPane.showMessageDialog(null,"A difernça entre os valores é" +N3);
         
     }
    }
    
}
