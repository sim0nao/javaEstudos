/*
Objetivo:Receba os valores em x e y. Efetua a troca de seus valores e mostre seus
conteúdos.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio6 
{
    public static void main (String args[])
    {
    int X,Y,X1;
    X=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor de X:"));
    Y=Integer.parseInt(JOptionPane.showInputDialog ("Digite o valor de Y:"));
    X1=X;
    X=Y;
    Y=X1;
    
    JOptionPane.showMessageDialog(null,"O valor de x:/n" +Y +"e o valor de y:/n" +X);
    
    }   
}
