/*
Objetivo:Receba 3 valores obrigatoriamente em ordem crescente e um 4º valor não
necessariamente em ordem. Mostre os 4 números em ordem crescente.
Data de criação: 05-03-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio23 
{
    public static void main (String args[])
    {
     int n1,n2,n3,n4;
     n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
     n2=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
     n3=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
     n4=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
     if ((n1>n2)&&(n2>n3))
     {
       JOptionPane.showMessageDialog(null,"Somente em ordem crescente");
     } 
        else if(n4>n3)
        {
          JOptionPane.showMessageDialog(null, n1 +n2 +n3 +n4);
        }
            else
        {
           JOptionPane.showMessageDialog(null,+n4 +n1 +n2 +n3);
     
         }
    }
}
