/*
 Objetivo:Receba os valores do comprimento, largura e altura de um paralelepípedo.
Calcule e mostre seu volume.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio7 
{
    public static void main (String args[])
    {
        double a,b,c,v;
        a=Integer.parseInt(JOptionPane.showInputDialog("Digite a largura do paralelepípedo"));
        b=Integer.parseInt(JOptionPane.showInputDialog("Digite o comprimento do paralelepípedo:"));
        c=Integer.parseInt(JOptionPane.showInputDialog("Digite a altura do paralelepípedo:"));
        v= a*b*c;
                
          JOptionPane.showMessageDialog(null,"O volume do paralelepípedo é:" +v); 
        
    }
}
