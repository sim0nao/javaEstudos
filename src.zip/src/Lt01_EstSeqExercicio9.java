/*
 Objetivo:Receba dois números inteiros, calcule e mostre a soma dos quadrados
Data de criação: 20-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio9 {
    public static void main (String args[])
    {
       int N1, N2,N3;
       N1=Integer.parseInt(JOptionPane.showInputDialog("Digite um valor:"));
       N2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro valor:"));
       N1=N1*N1;
       N2=N2*N2;
       N3=N1+N2;
        
       JOptionPane.showMessageDialog(null,"A soma será de:" +N3);
           
    }
    
}
