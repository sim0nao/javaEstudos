/*
Objetivo:Receba o valor de um depósito em poupança.Calcule e mostre o valor após 1
mês de aplicação sabendo que rende 1,3% a. m..
Data de criação: 20-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio8 {
    public static void main (String args[])
    {
        double I,R,T;
        I=Integer.parseInt(JOptionPane.showInputDialog("Valor do Investimento inicial:"));
        R=1.3;
        T= (I*R) + I;
        
        JOptionPane.showMessageDialog(null,"O valor do rendimento será de:" +T);
    }
    
    
}
