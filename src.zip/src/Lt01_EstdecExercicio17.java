/*
Objetivo:Calcule a quantidade de litros gastos em uma viagem, sabendo que o automóvel faz 12 km/l. 
Receber o tempo de percurso e a velocidade média.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstdecExercicio17 {
    public static void main (String args[])
    {
        double Lt,Tem,VelM;
        Tem=Integer.parseInt(JOptionPane.showInputDialog("Digite o tempo de percurso"));
        VelM=Integer.parseInt(JOptionPane.showInputDialog("Digite a velocidade média"));
        Lt=VelM/Tem;
        Lt=Lt/12;
        JOptionPane.showMessageDialog(null,"A quantidade de litros de gasolina será" +Lt);
    }
    
}
