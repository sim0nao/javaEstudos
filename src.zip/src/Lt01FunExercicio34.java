/*
 Objetivo: Receba um número. Calcule e mostre os resultados da tabuada desse número.
Data de criação:01-04-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01FunExercicio34 {
    static int Tabuada (int n){
        int c = 1; 
        int t=0;
        while(c<=10){
            t=c*n;
            c=c+1;
            JOptionPane.showMessageDialog(null,t);
        }
        
        return(t);    
    }
  public static void main (String args[]){
      int n1, ret;
      n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
      ret= Tabuada(n1);
      
      
  }  
}
