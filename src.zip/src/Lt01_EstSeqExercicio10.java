/*
 Objetivo:Receba a temperatura em graus Celsius. Calcule e mostre sua temperatura convertida
em Fahenheit F= (9*C + 160) /5.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio10 {
    public static void main (String args[]) 
    {
        double N1,N2,N3;
        N1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
        N2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número, menor que o anterior"));
        N3=(N1-N2);
        JOptionPane.showMessageDialog(null, "A diferença entre os valores é de:" +N3);
    }
    
}
