/*
Objetivo:Receba 2 números inteiros. Verifique e mostre se o maior número é múltiplo do
menor.
Data de criação: 11-03-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio26 
{
    public static void main (String args[])
            
    {
     int Num1, Num2, Maior;
     Num1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
     Num2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número:"));
        if (Num1>Num2)
        {
            if (Num1%Num2==0)
            {
            JOptionPane.showMessageDialog(null,+Num1, "é multilo de:", +Num2);
            }

            else
            {
            JOptionPane.showMessageDialog(null,+Num1, "Não é multilo de:", +Num2);
            }
        
         
            if (Num2%Num1==0) 
            {
               JOptionPane.showMessageDialog(null,+Num2, "é multilo de:", +Num1);   
            }
            else
            {
             JOptionPane.showMessageDialog(null,+Num1, "Não é multilo de:", +Num2);
            }
          }   
        
         
        }
     }

