/*
 Objetivo:Receba o ano de nascimento e o ano atual. Calcule e mostre a sua idade e
quantos anos terá daqui a 17 anos.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_EstSeqExercicio12 {
     public static void main (String args[])        
     {
         int A1, A2, I1, I2;
         A1=Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de nascimento"));
         A2=Integer.parseInt(JOptionPane.showInputDialog("Digite o ao atual"));
         I1=A2-A1;
         I2=I1+17;
         javax.swing.JOptionPane.showMessageDialog(null,"Você tem" +I1 +"anos e terá" +I2 +"anos");
         
         
     }
    
    
}
