/*
  28. Receba o preço atual e a média mensal de um produto. Calcule e mostre o novo
preço sabendo que:
Venda Mensal Preço Atual Preço Novo
< 500 < 30 + 10%
>= 500 e < 1000 >= 30 e < 80 +15%
>= 1000 >= 80 - 5%
Obs.: para outras condições, preço novo será igual ao preço atual.
Data de criação: 16-03-2019
Programadora: Simone Henrique
 */

public class Lt01EstDecExercicio28 {
    
}
