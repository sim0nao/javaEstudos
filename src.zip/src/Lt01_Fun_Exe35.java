/*
 Objetivo:Receba 2 números inteiros, verifique qual o maior entre eles.
Calcule e mostre o resultado da somatória dos números ímpares entre esses valores.
Data de criação: 10-04-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01_Fun_Exe35 {
    public static void main (String args[]){
        int n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
        int n2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número"));
        res=Dif(n1,n2);
        
    }
    static int Dif(int x, int y){
        if (x<y){
            for (int cont=y; cont<=x; cont++){
                if (double z=(cont%2=1
            } 
            
        }
        
    }
    
}
