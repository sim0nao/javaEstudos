/*
Objetivo:Receba 2 valores inteiros e diferentes. Mostre seus valores em ordem
crescente.
Data de criação: 14-02-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio22 
{
    public static void main (String args[])
    {
        double n1,n2;
        n1=Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
        n2=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número"));
        if (n1>n2)
        {
            JOptionPane.showMessageDialog(null, +n1 +n2);
        }
        else if (n2>n1)
        {
            JOptionPane.showMessageDialog(null, +n2 +n1);
       
        }
            else
            {
            JOptionPane.showMessageDialog(null, "Os número não podem ser iguais");
            }
    }
}
