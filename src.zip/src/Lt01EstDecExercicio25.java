/*
 Objetivo:Receba a hora de início e de final de um jogo (HH,MM), calcular o tempo do
jogo em horas e minutos, sabendo que o tempo máximo é menor que 24 horas e
pode começar num dia e terminar noutro.
Data de criação: 11-03-2019
Programadora: Simone Henrique
 */

import javax.swing.JOptionPane;
public class Lt01EstDecExercicio25 {
    public static void main (String args[])
    {
        double horaIn, horaFin;
        horaIn=Integer.parseInt(JOptionPane.showInputDialog("Digite a hora inicial do jogo:"));
        horaFin=Integer.parseInt(JOptionPane.showInputDialog("Digite a hora final do jogo:"));
        
        
        
        
        
        
        
    }
    
}
